document.addEventListener("DOMContentLoaded", () => {
  document.body.style.opacity = 0;
  document.body.animate([{opacity:0},{opacity:1}], {duration:900, fill:"forwards"});
});
